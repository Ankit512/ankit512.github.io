import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Github, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function DeploymentStatus() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);

  const owner = 'Ankit512';
  const repo = 'portfolio';
  const deploymentUrl = `https://${owner}.github.io/${repo}/`;
  const sourceRepo = `https://github.com/${owner}/${repo}`;

  useEffect(() => {
    const checkDeployment = async () => {
      try {
        // Check if the GitHub Pages site is accessible
        const response = await fetch(deploymentUrl);
        if (!response.ok) {
          throw new Error('Site deployment not accessible');
        }
        setError(null);
      } catch (err) {
        setError('Site deployment in progress. Please check:');
      } finally {
        setLoading(false);
      }
    };

    checkDeployment();
  }, [retryCount]);

  if (loading) {
    return (
      <Card className="w-full border-border bg-card/20">
        <CardContent className="p-4">
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card className="w-full border-border bg-card/20">
        <CardContent className="p-4">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="secondary" className="bg-purple-600/10 text-purple-600">
                GitHub Pages
              </Badge>
            </div>

            {error ? (
              <>
                <div className="flex items-center gap-2 text-muted-foreground">
                  <AlertCircle className="h-5 w-5" />
                  <p className="text-sm">{error}</p>
                </div>

                <div className="space-y-3 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-yellow-500" />
                    <span>GitHub Actions workflow status</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full bg-yellow-500" />
                    <span>Pages deployment progress</span>
                  </div>
                </div>

                <div className="flex flex-col gap-2 mt-4">
                  <p className="text-sm text-muted-foreground font-medium">Next Steps:</p>
                  <ol className="list-decimal list-inside text-sm text-muted-foreground space-y-2 ml-2">
                    <li>Check Actions tab for deployment progress</li>
                    <li>Wait for the workflow to complete</li>
                    <li>Refresh this page in a few minutes</li>
                  </ol>
                </div>
              </>
            ) : (
              <p className="text-sm text-muted-foreground">
                Site deployment status and configuration
              </p>
            )}

            <div className="flex flex-wrap gap-3 mt-2">
              <Button variant="outline" size="sm" asChild>
                <a
                  href={`${sourceRepo}/actions`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <Github className="h-4 w-4" />
                  View Actions
                </a>
              </Button>

              <Button variant="outline" size="sm" asChild>
                <a
                  href={deploymentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <ExternalLink className="h-4 w-4" />
                  Visit Site
                </a>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}