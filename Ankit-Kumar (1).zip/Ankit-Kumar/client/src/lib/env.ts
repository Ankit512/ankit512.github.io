// Environment configuration for GitHub Pages deployment
export const getBasePath = () => {
  // For GitHub Pages, check if we're on the production domain
  if (import.meta.env.PROD && window.location.hostname.includes('github.io')) {
    // Log the environment detection
    console.log('GitHub Pages environment detected');
    return '/portfolio';
  }
  console.log('Development environment detected');
  return '';
};

export const getAssetPath = (path: string) => {
  const base = getBasePath();
  // Remove leading slash if present to avoid double slashes
  const cleanPath = path.startsWith('/') ? path.slice(1) : path;

  // For GitHub Pages (production), use base-prefixed paths
  if (import.meta.env.PROD && base) {
    // Use relative paths for assets in production
    const relativePath = `./${cleanPath}`;
    console.log(`Asset path resolved: ${path} -> ${relativePath}`);
    return relativePath;
  }

  // For development, use absolute paths
  const absolutePath = `/${cleanPath}`;
  console.log(`Asset path resolved: ${path} -> ${absolutePath}`);
  return absolutePath;
};