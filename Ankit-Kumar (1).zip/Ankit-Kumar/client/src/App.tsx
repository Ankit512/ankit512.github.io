import React from 'react';
import { Router, Route, Switch } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Nav from "@/components/nav";
import { ThemeProvider } from "@/components/theme-provider";
import ThemeToggle from "@/components/theme-toggle";
import ParticlesBackground from "@/components/particles-background";
import { getBasePath } from "@/lib/env";

// Enhanced hash-based routing hook for GitHub Pages
const useHashLocation = () => {
  const [loc, setLoc] = React.useState(() => {
    const hash = window.location.hash.slice(1) || "/";
    console.log('Initial route:', hash);
    return hash;
  });

  React.useEffect(() => {
    const handler = () => {
      const hash = window.location.hash.slice(1) || "/";
      console.log('Route changed to:', hash);
      setLoc(hash);
    };

    window.addEventListener("hashchange", handler);

    // Set initial hash if none exists
    if (!window.location.hash) {
      console.log('Setting initial hash to #/');
      window.location.hash = "#/";
    }

    return () => window.removeEventListener("hashchange", handler);
  }, []);

  const navigate = React.useCallback((to: string) => {
    console.log('Navigating to:', to);
    window.location.hash = to;
  }, []);

  return [loc, navigate] as const;
};

function App() {
  // Log environment information on mount
  React.useEffect(() => {
    console.log('App mounted');
    console.log('Base path:', getBasePath());
    console.log('Current URL:', window.location.href);
    console.log('Hash:', window.location.hash);
    console.log('Pathname:', window.location.pathname);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="dark" storageKey="portfolio-theme">
        <Router hook={useHashLocation}>
          <div className="relative min-h-screen bg-background text-foreground antialiased">
            <ParticlesBackground />
            <div className="relative z-10">
              <Nav />
              <Switch>
                <Route path="/" component={Home} />
                <Route component={NotFound} />
              </Switch>
              <ThemeToggle />
            </div>
            <Toaster />
          </div>
        </Router>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;