import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Ensure the app knows about the base URL when deployed to GitHub Pages
const baseUrl = import.meta.env.PROD && window.location.hostname.includes('github.io') 
  ? '/portfolio/' 
  : '/';

// Set data attribute for use in CSS/JS
document.documentElement.dataset.baseUrl = baseUrl;

// Log deployment information
console.log('Environment:', import.meta.env.MODE);
console.log('Base URL:', baseUrl);
console.log('Current Path:', window.location.pathname);
console.log('Hash:', window.location.hash);

// Handle initial routing for GitHub Pages
if (import.meta.env.PROD && window.location.hostname.includes('github.io')) {
  // If we're at the root of the portfolio without a hash, add one
  if (window.location.pathname === '/portfolio/' && !window.location.hash) {
    window.location.replace('/portfolio/#/');
  }
}

createRoot(document.getElementById("root")!).render(<App />);